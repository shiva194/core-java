package com.xworkz.civilengineer;

import com.xworkz.engineer.Engineer;

public class CivilEngineer extends Engineer {
}
