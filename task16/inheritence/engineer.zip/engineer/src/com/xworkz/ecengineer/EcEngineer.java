package com.xworkz.ecengineer;

import com.xworkz.engineer.Engineer;

public class EcEngineer extends Engineer {
}
