package com.xworkz.mechengineer;

import com.xworkz.engineer.Engineer;

public class MechEngineer extends Engineer {
}
