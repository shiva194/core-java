package com.xworkz.aiml;

import com.xworkz.engineer.Engineer;

public class AiMl extends Engineer {
}
