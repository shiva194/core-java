package com.xworkz.engineer;

public class Engineer {

          public void  ProblemSolving(){
              System.out.println("method started");

              System.out.println("Dont Worry i will Provide Solution");

              System.out.println("method ended");
          }
}
